TriggerEvent("es:activateMoney",0)
TriggerEvent("es:activateBlackMoney",0)
TriggerEvent("es:activateJob","👻 Police")
TriggerEvent("es:activateJob2","👁 Houmma")


--- MODE PO OTAGE
--- SUPERETTE MAIN SUR LA TETE PNJ FICTIF + LIBERER
--- APPLICATION UBER GCPHONE
--- xp -> darknet -> armes
--- blanchiment à réfléchir
--- coffre individuel lspd (casier)
--- micro camera perche item journaliste
--- taxi course moldi
--- branquart lsmd
--- raffinerie ? 
--- agence immo -> todo
--- gouv sécu
--- ferailleur changer plaques + fourière
--- licence meth
--- limtie run/jour
