Locales['sv'] = {
  ['left_instance'] = 'du har lämnat byggnaden',
  ['invite_expired'] = 'din inbjudan har nekas',
  ['press_to_enter'] = 'tryck ~INPUT_CONTEXT~ för att gå in i byggnaden',
  ['entered_instance'] = 'du är inne i byggnaden',
  ['entered_into'] = '%s gick in i byggnaden',
  ['left_out'] = '%s har lämnat byggnaden',
}