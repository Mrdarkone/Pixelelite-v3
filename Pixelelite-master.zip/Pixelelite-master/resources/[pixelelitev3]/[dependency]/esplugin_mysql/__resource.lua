server_script '@mysql-async/lib/MySQL.lua'
server_script 'uuid.js'
server_script 'server.lua'