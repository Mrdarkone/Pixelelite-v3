description 'early init for game script'

client_script 'init.lua'
server_script 'server.lua'
