resource_manifest_version '05cfa83c-a124-4cfa-a768-c24a5811d8f9'
this_is_a_map 'yes'
client_script "client.lua"  

file 'phantaprops.ytyp'
data_file 'DLC_ITYP_REQUEST' 'phantaprops.ytyp'
